-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 11 Juni 2021 pada 20.35
-- Versi Server: 10.1.30-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_resto`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, 'create_users_table', 1),
(2, 'password_resets_table', 1),
(3, 'create_tb_hidangan_table', 1),
(5, 'create_tb_pelanggan_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_hidangan`
--

CREATE TABLE `tb_hidangan` (
  `id_hidangan` int(10) UNSIGNED NOT NULL,
  `nama_hidangan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi_hidangan` text COLLATE utf8mb4_unicode_ci,
  `harga_hidangan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kategori_hidangan` enum('Burger','Salad','Dessert','Minuman','Breakfast') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto_hidangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `tb_hidangan`
--

INSERT INTO `tb_hidangan` (`id_hidangan`, `nama_hidangan`, `deskripsi_hidangan`, `harga_hidangan`, `kategori_hidangan`, `foto_hidangan`, `created_at`, `updated_at`) VALUES
(1, 'Cheese Burger', 'Beri ruang untuk Burger Cheeseburger ganda kami, dua roti daging bakar bakar yang dibumbui dengan lapisan sederhana keju Amerika yang meleleh, acar belok keriting, mustard kuning, dan saus tomat pada roti biji wijen panggang.', 'Rp 31.818', 'Burger', 'burger_cheese_burger.png', '2021-06-11 15:10:18', '22021-06-11 15:10:18'),
(2, 'Chicken Garden Salad', 'Salad Taman Ayam kami adalah campuran romain hijau renyah, daun hijau dan selada radicchio, tomat matang, crouton bawang putih, dan keju cheddar parut.', 'Rp 18.181', 'Salad', 'salad_ChickenGardenSalad.png', '2021-06-11 15:10:18', '2021-06-11 15:10:18'),
(3, 'Coca Cola', '© The Coca-Cola Company. \"Coke\" adalah merek dagang terdaftar dari The Coca-Cola Company.', 'Rp 7.727', 'Minuman', 'minuman_coca_cola.png', '2021-06-11 15:10:18', '2021-06-11 15:10:18'),
(4, 'Es Krim', 'Kami tidak menciptakan servis yang lembut, tetapi dengan satu rasa Vanilla Soft Serve kami yang dingin, lembut, dan lembut, Anda akan berpikir kami menyempurnakannya. Pilihan kerucut atau can', 'Rp 4.545', 'Dessert', 'dessert_es_krim.png', '2021-06-11 15:10:18', '2021-06-11 15:10:18');
-- --------------------------------------------------------


--
-- Struktur dari tabel `tb_pelanggan`
--

CREATE TABLE `tb_pelanggan` (
  `id_pelanggan` int(10) UNSIGNED NOT NULL,
  `nama_pelanggan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_pelanggan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username_pelanggan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_pelanggan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto_pelanggan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `tb_pelanggan`
--

INSERT INTO `tb_pelanggan` (`id_pelanggan`, `nama_pelanggan`, `email_pelanggan`, `username_pelanggan`, `password_pelanggan`, `foto_pelanggan`, `created_at`, `updated_at`) VALUES
(1, 'Putu Jhonarendra', 'jhonarendra@gmail.com', 'jhonarendra', 'f80cdc281e09fb8f69607830dd9586c4', NULL, '2018-11-14 15:10:18', '2018-11-14 15:10:18'),
(2, 'his', 'hus', 'hus', 'ee4b742d5fc2159c78cd15cef9d238d1', NULL, '2018-11-15 20:02:47', '2018-11-15 20:02:47'),
(3, 'jho', 'jho', 'jho', '1427e904d3da3b984e2cd6e82d97d631', NULL, '2018-11-15 20:06:09', '2018-11-15 20:06:09');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `tb_hidangan`
--
ALTER TABLE `tb_hidangan`
  ADD PRIMARY KEY (`id_hidangan`);

--
-- Indexes for table `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_hidangan`
--
ALTER TABLE `tb_hidangan`
  MODIFY `id_hidangan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tb_pelanggan`
--
ALTER TABLE `tb_pelanggan`
  MODIFY `id_pelanggan` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--